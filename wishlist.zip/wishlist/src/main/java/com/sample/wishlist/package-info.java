/*
 * Created with [y] YaaS Service SDK version 4.12.1.
 */
/**
 * Contains the application config.
 */
package com.sample.wishlist;
