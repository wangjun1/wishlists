/**
 * Soon javadoc will get generated here proper.
 */
package com.sample.wishlist.api.generated;
